/**
 * Community bundle ordering — issue #98 (phase 2): let the user reorder the
 * community bundles of the profile's layer stack, with author-declared
 * before/after rules enforced before anything is written.
 *
 * Official in-box bundles (@deepseek-ai/dsh-base, @deepseek-ai/dsh-web-app,
 * @deepseek-ai/dsh-headless) are fixed: they keep their exact positions in
 * the stack, are never part of a user-supplied order, and are never added,
 * removed or duplicated by a reorder (#98 boundary). The profile's own
 * cordis.patch.yml and --patch overlays are not part of the bundle stack and
 * are never touched here.
 *
 * Read-only helpers — nothing here writes the manifest; no processes, no
 * network. The write side (mergeOrder / applyBundleOrder) lives on the
 * ordering branch.
 */

import { existsSync, readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join, resolve } from 'node:path'

/** Profile bundles that ship with the dsh host and must stay put (#98). */
export const INBOX_BUNDLES = new Set([
  '@deepseek-ai/dsh-base',
  '@deepseek-ai/dsh-web-app',
  '@deepseek-ai/dsh-headless',
])

/** The bundle stack as it appears in the profile manifest. */
export interface BundleStack {
  /** Full ordered list from dsh.profile.bundles. */
  bundles: string[]
  /** The subset that may be reordered (community bundles). */
  community: string[]
}

/** Author-declared ordering constraints of one bundle. */
export interface BundleRule {
  name: string
  /** This bundle must load after every name in this list. */
  after: string[]
  /** This bundle must load before every name in this list. */
  before: string[]
}

/** A violated before/after rule in the current or proposed order. */
export interface OrderConflict {
  name: string
  reason: string
}

/** Read the profile's bundle stack (empty when the manifest is unreadable). */
export function readBundleStack(profileDir: string): BundleStack {
  try {
    const manifest = JSON.parse(readFileSync(join(profileDir, 'package.json'), 'utf8')) as {
      dsh?: { profile?: { bundles?: unknown } }
    }
    const bundles = Array.isArray(manifest.dsh?.profile?.bundles)
      ? manifest.dsh.profile.bundles.filter((name): name is string => typeof name === 'string')
      : []
    return {
      bundles,
      community: bundles.filter(name => !INBOX_BUNDLES.has(name)),
    }
  } catch {
    return { bundles: [], community: [] }
  }
}

/**
 * Locate the dsh host installation from the process entry (same source as
 * dsh-cli.ts / check.ts): walk up from dirname(argv[1]) until a package.json
 * named @deepseek-ai/dsh is found.
 */
function findDshInstallDir(entry = process.argv[1]): string | null {
  if (entry === undefined) return null
  let dir = resolve(dirname(entry))
  for (let depth = 0; depth < 10; depth += 1) {
    try {
      const manifest = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) as { name?: unknown }
      if (manifest.name === '@deepseek-ai/dsh') return dir
    } catch { /* keep walking up */ }
    const parent = dirname(dir)
    if (parent === dir) return null
    dir = parent
  }
  return null
}

/**
 * The bundle package.json, resolved the way the dsh boot resolves bundles
 * (dsh-app-boot's resolveBundleDir, mirrored by check.ts): the dsh
 * installation anchor first — official in-box bundles live in the install's
 * node_modules, never the profile's — then the profile directory, whose
 * createRequire search paths also cover pnpm workspace-root hoisting
 * (`<profiles>/node_modules` when the profile lives under `<profiles>/<name>`).
 */
function resolveBundlePackageJson(profileDir: string, name: string): string | null {
  const dshInstall = findDshInstallDir()
  const anchors = [
    dshInstall !== null ? join(dshInstall, 'package.json') : null,
    join(profileDir, 'package.json'),
  ]
  for (const anchor of anchors) {
    if (anchor === null) continue
    let paths: string[] = []
    try {
      paths = createRequire(anchor).resolve.paths(name) ?? []
    } catch {
      continue
    }
    for (const searchPath of paths) {
      const candidate = join(searchPath, name)
      if (existsSync(join(candidate, 'package.json'))) return join(candidate, 'package.json')
    }
  }
  return null
}

/**
 * Read each bundle's declared ordering rules from its package manifest
 * (`dsh.bundle.order.{before,after}` — a list of bundle package names).
 * Unresolvable packages and missing declarations contribute nothing.
 */
export function readBundleRules(profileDir: string): BundleRule[] {
  const { bundles } = readBundleStack(profileDir)
  const rules: BundleRule[] = []
  for (const name of bundles) {
    const packageJson = resolveBundlePackageJson(profileDir, name)
    if (packageJson === null) continue
    try {
      const manifest = JSON.parse(
        readFileSync(packageJson, 'utf8'),
      ) as { dsh?: { bundle?: { order?: unknown } } }
      const order = manifest.dsh?.bundle?.order
      if (order === null || typeof order !== 'object' || Array.isArray(order)) continue
      const listOf = (value: unknown): string[] => Array.isArray(value)
        ? value.filter((item): item is string => typeof item === 'string')
        : []
      const rule: BundleRule = {
        name,
        after: listOf((order as Record<string, unknown>).after),
        before: listOf((order as Record<string, unknown>).before),
      }
      if (rule.after.length > 0 || rule.before.length > 0) rules.push(rule)
    } catch { /* package unreadable — no rule */ }
  }
  return rules
}

/**
 * Check a bundle order against the declared before/after rules. Rules naming
 * bundles outside `order` are ignored (a rule for a not-yet-installed bundle
 * must not block the current stack).
 * @returns every violated rule with a readable reason; [] when all hold.
 */
export function validateOrder(bundleNames: string[], rules: BundleRule[]): OrderConflict[] {
  const position = new Map(bundleNames.map((name, index) => [name, index]))
  const conflicts: OrderConflict[] = []
  for (const rule of rules) {
    const pos = position.get(rule.name)
    if (pos === undefined) continue
    for (const other of rule.after) {
      const otherPos = position.get(other)
      if (otherPos === undefined) continue
      if (otherPos >= pos) {
        conflicts.push({
          name: rule.name,
          reason: `must load after ${other}, but ${other} is currently before/equal (position ${otherPos} vs ${pos})`,
        })
      }
    }
    for (const other of rule.before) {
      const otherPos = position.get(other)
      if (otherPos === undefined) continue
      if (otherPos <= pos) {
        conflicts.push({
          name: rule.name,
          reason: `must load before ${other}, but ${other} is currently after/equal (position ${otherPos} vs ${pos})`,
        })
      }
    }
  }
  return conflicts
}

/**
 * Topologically sort the community bundles by their before/after rules AND
 * plugin-to-plugin dependencies — the "auto-fix" counterpart to validateOrder
 * (LOOT-style): the suggested order satisfies every declared rule and puts
 * each bundle after the bundles it depends on. Kahn's algorithm with
 * deterministic tie-breaking (stable input order). Bundles without
 * constraints keep their relative order among the unconstrained ones.
 *
 * `dependencyEdges` expresses "from depends on to" (usually read from each
 * bundle's dependencies/peerDependencies that name another community
 * bundle); the constraint is `to` must load before `from`.
 * @returns the suggested community order, or a cycle report when the
 * constraints cannot be satisfied (references to unlisted bundles ignored).
 */
export function suggestOrder(
  bundleNames: string[],
  rules: BundleRule[],
  dependencyEdges: Array<{ from: string; to: string }> = [],
): { ok: true; order: string[] } | { ok: false; cycle: string[] } {
  const names = bundleNames.filter(name => !INBOX_BUNDLES.has(name))
  const inOrder = new Set(names)
  const active = rules.filter(rule => inOrder.has(rule.name))
  // Constraint: "a must load before b" (from a.before or b.after) → edge a → b.
  const beforeOf = new Map<string, Set<string>>() // name → bundles that must come after it
  const deps = new Map<string, Set<string>>() // name → bundles that must come before it
  for (const name of names) {
    beforeOf.set(name, new Set())
    deps.set(name, new Set())
  }
  const addEdge = (a: string, b: string): void => {
    if (!inOrder.has(a) || !inOrder.has(b) || a === b) return
    beforeOf.get(a)?.add(b)
    deps.get(b)?.add(a)
  }
  for (const rule of active) {
    for (const other of rule.before) addEdge(rule.name, other)
    for (const other of rule.after) addEdge(other, rule.name)
  }
  // Dependency edges: "from depends on to" ⇒ to must load before from.
  for (const edge of dependencyEdges) addEdge(edge.to, edge.from)
  const remaining = new Map<string, Set<string>>()
  for (const [name, depsOf] of deps) remaining.set(name, new Set(depsOf))
  const ready: string[] = names.filter(name => (remaining.get(name)?.size ?? 0) === 0)
  const ordered: string[] = []
  while (ready.length > 0) {
    // Deterministic, INPUT-INDEPENDENT tie-break: the ready bundle with the
    // smallest name. The suggested order is therefore UNIQUE for a given set
    // of bundles/rules/dependencies — it never chases the user's current
    // manual order, so re-clicking auto-sort after hand-tweaking an
    // unconstrained bundle restores the same canonical result.
    let best = 0
    for (let i = 1; i < ready.length; i += 1) {
      const a = ready[i]
      const b = ready[best]
      if (a !== undefined && b !== undefined && a.localeCompare(b) < 0) best = i
    }
    const name = ready.splice(best, 1)[0]
    if (name === undefined) break
    ordered.push(name)
    for (const dependent of beforeOf.get(name) ?? []) {
      const depsOf = remaining.get(dependent)
      if (depsOf === undefined) continue
      depsOf.delete(name)
      if (depsOf.size === 0 && !ordered.includes(dependent) && !ready.includes(dependent)) ready.push(dependent)
    }
  }
  if (ordered.length < names.length) {
    return { ok: false, cycle: names.filter(name => !ordered.includes(name)) }
  }
  return { ok: true, order: ordered }
}
